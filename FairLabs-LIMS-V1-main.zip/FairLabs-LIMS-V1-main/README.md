# FairLabs-LIMS-V1
LIMS Version 1 from Google firebase



# Firebase Studio

This is a NextJS starter in Firebase Studio.

To get started, take a look at src/app/page.tsx.

