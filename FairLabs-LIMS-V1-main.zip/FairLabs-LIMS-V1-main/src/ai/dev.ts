import { config } from 'dotenv';
config();

import '@/ai/flows/validate-result-flow.ts';
