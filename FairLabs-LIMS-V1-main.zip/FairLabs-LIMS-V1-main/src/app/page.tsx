
import FairLabsLIMS from '@/components/lims/FairLabsLIMS';

export default function Home() {
  return <FairLabsLIMS />;
}
